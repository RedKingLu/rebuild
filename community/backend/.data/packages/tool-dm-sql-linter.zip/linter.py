# placeholder linter
print('scan')